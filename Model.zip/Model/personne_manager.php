<?php
	// Fichier de connection à la BDD
	require_once("manager.php");
	
	class personne_manager extends manager{
		
		public function findAll(){
			// Récupération des personnes dans la BDD
<<<<<<< HEAD
			$strRequete		= "SELECT PersonneId, Nom, Prenom,Telephone,Email,RoleId
=======
			$strRequete		= "SELECT PersonneId, 
			                          Nom, 
									  Prenom,
									  Email,
									  Telephone,
									  RoleId
>>>>>>> a346f08e6f180000ec5944bf089ec939af95ab1f
								FROM Personne ";
			$requete 		= $this->_db->query($strRequete);
			return $requete->fetchAll();				
		}
		
		public function getByMail(){
<<<<<<< HEAD
			$strRequete		= "SELECT PersonneId, Nom, Prenom,Telephone,Telephone,Email,RoleId
=======
			$strRequete		= "SELECT PersonneId, Nom, Pernom,RoleId
>>>>>>> a346f08e6f180000ec5944bf089ec939af95ab1f
								FROM Personne 
								WHERE Email = '".$_POST['mail']."' ";
			$requete 		= $this->_db->query($strRequete);
			return $requete->fetch();
		}
		
		public function getById(){
<<<<<<< HEAD
			$strRequete		= "SELECT PersonneId, Nom, Prenom,Telephone,Telephone,Email,RoleId
								FROM Personne 
								WHERE PersonneId = '".$_POST['personne']['personneId']."' ";
			$requete 		= $this->_db->query($strRequete);
			return $requete->fetch();
		}
		
		public function editPersonne($objPersonne){
			$strReq = "UPDATE Personne 
						SET Nom =:nom,
						Prenom=:prenom, Emai=:email, RoleId=:roleId,
						Telephone=:telephone	
						WHERE PersonneId = :personneId";

			$prep	= $this->_db->prepare($strReq);
			$prep->bindValue(':personneId',$objPersonne->getPersonneId(), PDO::PARAM_INT);
			$prep->bindValue(':nom', $objPersonne->getNom(), PDO::PARAM_STR);
			$prep->bindValue(':prenom',$objPersonne->getPrenom(), PDO::PARAM_STR);
			$prep->bindValue(':telephone',$objPersonne->getTelephone(), PDO::PARAM_INT);
			$prep->bindValue(':email',$objPersonne->getEmail(), PDO::PARAM_STR);
			$prep->bindValue(':roleId',$objPersonne->getRoleId(), PDO::PARAM_INT);
			return $prep->execute();
		}

		public function addPersonne($objPersonne){
			$strReq = "INSERT INTO Personne 
			            (Nom, Prenom,Telephone,Email,RoleId)
						VALUES (:nom, :prenom,:telephone, :email, :roleId)";
			$prep	= $this->_db->prepare($strReq);	
			$prep->bindValue(':nom',$objPersonne->getNom(), PDO::PARAM_STR);
			$prep->bindValue(':prenom',$objPersonne->getPrenom(), PDO::PARAM_STR);
			$prep->bindValue(':telephone',$objPersonne->getTelephone(), PDO::PARAM_INT);
			$prep->bindValue(':email',$objPersonne->getEmail(), PDO::PARAM_STR);
			$prep->bindValue(':roleId',$objPersonne->getRoleId(), PDO::PARAM_INT);
			return $prep->execute();
		}

		public function deletePersonne($id){
			$strReq = "DELETE FROM Personne 
			            WHERE PersonneId = :personneId";
			$prep	= $this->_db->prepare($strReq);
			$prep->bindValue(':personneId',$id, PDO::PARAM_INT);
			return $prep->execute();
=======
			$strRequete		= "SELECT PersonneId, Nom, Pernom,RoleId,Email
								FROM Personne 
								WHERE PersonneId = '".$_SESSION['personne']['personneId']."' ";
			$requete 		= $this->_db->query($strRequete);
			return $requete->fetch();
		}

		public function addPerson($objPersonne){
			$strReq = "INSERT INTO personne (Nom, Prenom, Telephone, Email, RoleId) 
			VALUES (:nom, :prenom, :telephone, :email, :roleid)";
			$prep	= $this->_db->prepare($strReq);
			$prep->bindValue(':nom', $objPersonne->getNom(), PDO::PARAM_STR);
			$prep->bindValue(':prenom', $objPersonne->getPreNom(), PDO::PARAM_STR);
			$prep->bindValue(':email', $objPersonne->getEmail(), PDO::PARAM_STR);
			$prep->bindValue(':telephone', $objPersonne->getTelephone(), PDO::PARAM_STR);
			$prep->bindValue(':roleid',$objPersonne->getRoleId(), PDO::PARAM_INT);
			return $prep->execute();	
		}
		
		public function editPersonne($objPersonne){
			$strRequete		= "UPDATE Personne 
								SET Nom = :nom,
									Prenom = :prenom,
									Telephone = :telephone,
									RoleId = :roleid,
									Email = :email;
							   WHERE Personneid = :personneid ";
			$prep	= $this->_db->prepare($strRequete);	
			$prep->bindValue(':personneid',$objPersonne->getPersonneId(), PDO::PARAM_INT);
			$prep->bindValue(':nom', $objPersonne->getNom(), PDO::PARAM_STR);
			$prep->bindValue(':prenom', $objPersonne->getPreNom(), PDO::PARAM_STR);
			$prep->bindValue(':email', $objPersonne->getEmail(), PDO::PARAM_STR);
			$prep->bindValue(':telephone', $objPersonne->getTelephone(), PDO::PARAM_STR);
			$prep->bindValue(':roleid',$objPersonne->getRoleId(), PDO::PARAM_INT);
			return $prep->execute();	

			return $this->_db->exec($strRequete);
		}

		public function deletePersonne($Id){
			$strRequete		= "delete from Personne where Personneid = :personneid";
			$prep	= $this->_db->prepare($strRequete);	
			$prep->bindValue(':personneid',$Id, PDO::PARAM_INT);
			return $prep->execute();	

			return $this->_db->exec($strRequete);

>>>>>>> a346f08e6f180000ec5944bf089ec939af95ab1f
		}
	}
    