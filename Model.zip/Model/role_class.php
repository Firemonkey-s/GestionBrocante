  <?php 
<<<<<<< HEAD
	class role_class{
		// Attributs
		private $_roleId;
		private $_titre;
		
		        

		// constructeur
		public function __construct(){
		}
		
		public function hydrate($arrRole){
			$this->setRoleId($arrRole['RoleId']);		
			$this->setTitre ($arrRole['Titre']);
           
			
		}
		
		// GETTERS
		public function getRoleId(){
			return $this->_roleId;
		}
		
		public function getTitre(){
			return $this->_titre;
		}
		
		
		
		// SETTERS 
		public function setRoleId($intRoleId){
			$this->_roleId = $intRoleId;
		}
		             
		public function setTitre ($strTitre ){
			$this->_titre  = $strTitre ;
		}
		
		
		
	}
=======
    class role_class
    {
        // Attributs
        private $_roleId;
        private $_titre ;
        
                

        // constructeur
        public function __construct()
        {
        }
        
        public function hydrate($arrRole)
        {
            $this->setRoleId($arrRole['RoleId']);
            $this->setTitre($arrRole['Titre']);
        }
        
        // GETTERS
        public function getRoleId()
        {
            return $this->_roleId;
        }
        
        public function getTitre()
        {
            return $this->_titre;
        }
        
        
        
        // SETTERS
        public function setRoleId($intRoleId)
        {
            $this->_roleId = $intRoleId;
        }
                     
        public function setTitre($strTitre)
        {
            $this->_titre  = $strTitre ;
        }
    }
>>>>>>> a346f08e6f180000ec5944bf089ec939af95ab1f
