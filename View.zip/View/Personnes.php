<<<<<<< HEAD
<br>
<br>
<br>
<br>
<br>
<h2>Liste des personnes</h2>


<a class="nav-link" href="Index.php?ctrl=Personnes&action=addPersonne">nouveau</a>

<?php 
foreach ($arrPersonnes as $arrPersonne){
                        $objPersonne = new personne_class();
                        
                        $objPersonne->hydrate($arrPersonne);
        
                         ?>
                          <p>**<?php echo $objPersonne->getNom().' '.$objPersonne->getPrenom() ?>.....<a href="">.....</a></p>
                        <?php } ?>

=======
<h2>Liste du personnel</h2>
<a href="index.php?ctrl=Personnes&action=addPerson">Nouveau</a>  
<?php 
foreach ($arrPersonnes as $arrPersonne){
                        $obj = new personne_class();
                        $obj->hydrate($arrPersonne);
                  ?> 
                          <p>   Nom : <?php echo $obj->GetNom()." ".$obj->GetPreNom()." ".$obj->GetEmail()." ".$obj->GetTelephone() ?>
                            <a href="">  Modifier</a>
                        </p>
                        <?php } ?>
                        <p></p>
                                              
>>>>>>> a346f08e6f180000ec5944bf089ec939af95ab1f



