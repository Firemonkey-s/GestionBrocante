<<<<<<< HEAD
<br>
<br>
<br>
<br>
<br>
=======
<<<<<<< HEAD
>>>>>>> a346f08e6f180000ec5944bf089ec939af95ab1f
<h2>Liste des roles</h2>
<?php 
foreach ($arrRoles as $arrRole){
                        $objRole = new role_class();
<<<<<<< HEAD
                        
                        $objRole->hydrate($arrRole);
        
                         ?>
                          <p>Libelle:<?php echo $objRole->getTitre() ?><a href="">Modifier</a></p>
=======
                        $objRole->hydrate($arrRole);
                  ?>
                          <p>   Titre : <?php echo $objRole->GetTitre() ?><a href="">  Modifier</a></p>
>>>>>>> a346f08e6f180000ec5944bf089ec939af95ab1f
                        <?php } ?>



=======
<h2>Liste des roles</h2>
<?php 
foreach ($arrRoles as $arrRole){
                        $objRole = new role_class();
                        $objRole->hydrate($arrRole);
                  ?>
                          <p>   Titre : <?php echo $objRole->GetTitre() ?><a href="">  Modifier</a></p>
                        <?php } ?>



>>>>>>> ad41158f8e1859d681ecaaab29648fd06a51ecb9
